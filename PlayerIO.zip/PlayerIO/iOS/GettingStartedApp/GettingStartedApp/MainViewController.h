//
//  MainViewController.h
//  GettingStartedApp
//
//  Created by Arash Rassouli on 3/12/14.
//  Copyright (c) 2014 yahoo. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainViewController : UIViewController

@end
